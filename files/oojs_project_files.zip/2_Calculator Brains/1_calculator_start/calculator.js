var calculator = {
		sum: 0,
		add: function(value) {

    },
    clear: function() {

    }, 
    equals: function() {

    }
}
