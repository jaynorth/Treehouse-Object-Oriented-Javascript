function Song() {

}

Song.prototype.play = function() {

};

Song.prototype.stop = function() {

};

Song.prototype.toHTML = function() {

};