function Playlist() {

}

Playlist.prototype.add = function() {

};

Playlist.prototype.play = function() {

};

Playlist.prototype.stop = function(){

};

Playlist.prototype.next = function() {

};

Playlist.prototype.renderIn = function() {

};